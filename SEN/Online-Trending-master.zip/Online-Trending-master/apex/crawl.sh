#!/bin/bash

python manage.py crawl google-news bbc-sport entertainment-weekly reddit nytimes hn