$(function () {
  var pathname = window.location.pathname;
  $('.menu-stories li a[href="'+ pathname +'"]').addClass('active');
});
