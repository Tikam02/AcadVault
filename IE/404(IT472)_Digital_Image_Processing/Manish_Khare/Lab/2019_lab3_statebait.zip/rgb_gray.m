% RGB TO GRAYSCALE
rgb_img = imread('wave.jpg');
sz = size(rgb_img);
gray_img = zeros(sz(1),sz(2));
rgb_img = im2double(rgb_img);
for i=1:sz(1)
    for j=1:sz(2)
        gray_img(i,j) = 0.2989*rgb_img(i,j,1) + 0.5870*rgb_img(i,j,2) + 0.1140*rgb_img(i,j,3);
    end
end
figure
subplot(2,1,1);
imshow(rgb_img);
subplot(2,1,2);
imshow(gray_img);