% RGB TO YIQ AND VICE VERSA
rgb_img = imread('wave.jpg');
sz = size(rgb_img);
rgb_img = im2double(rgb_img);
yiq_img = zeros(size(rgb_img));
matrix = [0.299 0.587 0.114 ; 0.596 -0.275 -0.321 ; 0.211 -0.532 0.311];
for i=1:sz(1)
    for j=1:sz(2)
          rgb = [rgb_img(i,j,1) rgb_img(i,j,2) rgb_img(i,j,3)];
          yiq_img(i,j,:) = matrix*transpose(rgb);
    end
end
inv_matrix = inv(matrix);
for i=1:sz(1)
    for j=1:sz(2)
        yiq = [yiq_img(i,j,1) yiq_img(i,j,2) yiq_img(i,j,3)];
        new_img(i,j,:) = inv_matrix*transpose(yiq);
    end
end

figure
subplot(1,5,1);
imshow(rgb_img);
title('Original Image');
subplot(1,5,2);
imshow(yiq_img(:,:,1));
title('Y Component');
subplot(1,5,3);
imshow(yiq_img(:,:,2));
title('I Component');
subplot(1,5,4);
imshow(yiq_img(:,:,3));
title('Q Component');
subplot(1,5,5);
imshow(new_img);
title('RGB from YIQ');