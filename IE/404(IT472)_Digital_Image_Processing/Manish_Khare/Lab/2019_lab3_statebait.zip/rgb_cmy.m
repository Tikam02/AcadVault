% RGB TO CMY AND VICE-VERSA
rgb_img = imread('wave.jpg');
sz = size(rgb_img);
rgb_img = im2double(rgb_img);
cmy_img = 1 - rgb_img;
new_img = 1 - cmy_img;

figure
subplot(3,3,1);
imshow(rgb_img);
title('Original image');
subplot(3,3,4);
imshow(cmy_img(:,:,1));
title('C component');
subplot(3,3,5);
imshow(cmy_img(:,:,1));
title('M component');
subplot(3,3,6);
imshow(cmy_img(:,:,1));
title('Y component');
subplot(3,3,2);
imshow(cmy_img);
title('CMY image');
subplot(3,3,3);
imshow(new_img);
title('RGB from CMY');