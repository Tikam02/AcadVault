% RGB TO HSI AND VICE VERSA
rgb_img = imread('wave.jpg');
sz = size(rgb_img);
rgb_img = im2double(rgb_img);
hsi_img = zeros(size(rgb_img));
for i=1:sz(1)
    for j=1:sz(2)
        R = rgb_img(i,j,1);
        G = rgb_img(i,j,2);
        B = rgb_img(i,j,3);
        theta = acosd(0.5*((R-G)+(R-B))/(sqrt((R-G)*(R-G)+(G-B)*(R-B))+0.000001));
        if(B>G) 
            theta = 360 - theta;
        end
        hsi_img(i,j,1) = theta/360;
        hsi_img(i,j,2) = 1 - 3*min(R,min(G,B))/(R+G+B+0.000001);
        hsi_img(i,j,3) = (R+G+B)/3;
    end
end

new_img = size(hsi_img);
for i=1:sz(1)
    for j=1:sz(2)
        H = hsi_img(i,j,1);
        S = hsi_img(i,j,2);
        I = hsi_img(i,j,3);
        R = 0;
        G = 0;
        B = 0;
        H = H*360;
        if (H>240)
            H = H-240;
            G = I*(1-S);
            B = I*(1+S*cosd(H)/cosd(60-H));
            R = 3*I - (G+B);
        elseif (H>120)
            H = H-120;
            R = I*(1-S);
            G = I*(1+S*cosd(H)/cosd(60-H));
            B = 3*I - (G+R);
        else
            B = I*(1-S);
            R = I*(1+S*cosd(H)/cosd(60-H));
            G = 3*I - (B+R);
        end
        new_img(i,j,1) = R;
        new_img(i,j,2) = G;
        new_img(i,j,3) = B;
    end
end

figure
subplot(1,5,1);
imshow(rgb_img);
title('Original Image');
subplot(1,5,2);
imshow(hsi_img(:,:,1));
title('Hue Component');
subplot(1,5,3);
imshow(hsi_img(:,:,2));
title('Saturation Component');
subplot(1,5,4);
imshow(hsi_img(:,:,3));
title('Intensity Component');
subplot(1,5,5);
imshow(new_img);
title('RGB from HSI');
