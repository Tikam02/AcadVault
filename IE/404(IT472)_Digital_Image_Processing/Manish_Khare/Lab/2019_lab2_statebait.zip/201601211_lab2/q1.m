I = imread('zelda.png');
[rows, columns] = size(I); 
angle = -45;
rads=2*pi*angle/360;  
rowsf = floor(rows*abs(cos(rads)) + columns*abs(sin(rads)));
colsf = floor(rows*abs(sin(rads)) + columns*abs(cos(rads)));
J = uint8(zeros(rowsf, colsf));
xo = floor(rows/2);                                                            
yo = floor(columns/2);
midx = floor(rowsf/2);
midy = floor(colsf/2);
for row=1:rowsf
    for col=1:colsf                                                       
        x = (row-midx)*cos(rads)+(col-midy)*sin(rads);                                       
        y = -(row-midx)*sin(rads)+(col-midy)*cos(rads);                             
        x = round(x) + xo;
        y = round(y) + yo;
        if (x>=1 && y>=1 && x<=rows &&  y<=columns) 
          J(row, col) = I(x, y);  
        end
    end
end
imshow(J);