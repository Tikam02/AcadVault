I = imread('zelda.png');
[rows, columns] = size(I);
J = uint8(zeros(2*rows, 2*columns));
shear_matrix = [1 1;0 1];
if (abs(shear_matrix(1, 2))<0.5) || (abs(shear_matrix(1, 2))<0.5)
    for r = 1:rows
        for c = 1:columns
            rp = floor(r + shear_matrix(1, 2)*c) ;
            cp = floor(c + shear_matrix(2, 1)*r) ;
            J(floor(rows*0.5)+rp, floor(columns*0.5)+cp) = I(r, c);
        end
    end
else
    disp('Shear value too high, tone it down!')
end
imshow(J);