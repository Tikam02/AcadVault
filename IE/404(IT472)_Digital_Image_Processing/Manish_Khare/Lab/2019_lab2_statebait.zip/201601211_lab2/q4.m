% Image roation

I = imread('zelda.png');
[rows, columns] = size(I); 
angle = -45;
rads=2*pi*angle/360;  
rowsf = floor(rows*abs(cos(rads)) + columns*abs(sin(rads)));
colsf = floor(rows*abs(sin(rads)) + columns*abs(cos(rads)));
J = uint8(zeros(rowsf, colsf));
xo = floor(rows/2);                                                            
yo = floor(columns/2);
midx = floor(rowsf/2);
midy = floor(colsf/2);
for row=1:rowsf
    for col=1:colsf                                                       
        x = (row-midx)*cos(rads)+(col-midy)*sin(rads);                                       
        y = -(row-midx)*sin(rads)+(col-midy)*cos(rads);                             
        x = round(x) + xo;
        y = round(y) + yo;
        if (x>=1 && y>=1 && x<=rows &&  y<=columns) 
          J(row, col) = I(x, y);  
        end
    end
end
imshow(J);

% Image Scaling and resizing

I = imread('zelda.png');
[rows, columns] = size(I);
M = 1024;
N = 1024;
J = uint8(zeros(M, N));
rowScale = rows/M;
colScale = columns/N;
for row=1:M
    for col=1:N
        orir = row*rowScale;
        oric = col*colScale;
        J(row, col) = newVal(I, orir, oric);
    end
end
imshow(J);

function [pix] = newVal(I, x, y)
    modXi = floor(x);
    modYi = floor(y);
    modXf = x - modXi;
    modYf = y - modYi;
    [rows, cols] = size(I);
    modXi = min(modXi, rows-1);
    modYi = min(modYi, cols-1);
    modXiPlusOneLim = min(modXi + 1, rows);
    modYiPlusOneLim = min(modYi + 1, cols);
    bl = I(modXi + 1, modYi + 1);
    br = I(modXiPlusOneLim, modYi + 1);
    tl = I(modXi+ 1, modYiPlusOneLim);
    tr = I(modXiPlusOneLim, modYiPlusOneLim);
    b = modXf*br + (1 - modXf)*bl;
    t = modXf*tr + (1 - modXf)*tl;
    pix = modYf*t + (1 - modYf)*b;
end

