I = imread('zelda.png');
[rows, columns] = size(I);
J = uint8(zeros(rows, columns));
tr = 50;
tc = 100;
if tr >= 0
    for r = 1:rows-tr
        J(r+tr, :) = I(r, :);
    end
else
    for r = 1:rows+tr
        J(r, :) = I(r-tr, :);
    end
end
I = J;
if tc >= 0
    for c = 1:columns-tc
        J(:, c+tc) = I(:, c);
    end
    J(:, 1:tc) = zeros(rows, tc);
else
    for c = 1:columns+tc
        J(:, c) = I(:, c-tc);
    end
    J(:, columns+tc+1:columns) = zeros(rows, -tc);
end
imshow(J);