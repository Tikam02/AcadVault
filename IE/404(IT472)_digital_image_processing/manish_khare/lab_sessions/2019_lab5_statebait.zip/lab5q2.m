%Non-Linear Filter
I = im2double(imread('lena.png'));
M1 = 2.*rand(3);
M2 = 2.*rand(5);
noise = 1;
J = linearFilter(I, M1, noise);

function y = linearFilter(I, M, noise)
    [rowi, coli] = size(I);
    [rowm, colm] = size(M);
    br = floor(rowm/2);
    bc = floor(colm/2);
    IC = zeros(rowi+4*br, coli+4*bc);
    y = IC;
    if noise==1
        I = imnoise(I,'salt & pepper');
    end
    imshow(I);
    figure();
    IC(2*br+1:rowi+2*br, 2*bc+1:coli+2*bc) = I;
    for i=1+br:rowi+3*br
        for j=1+bc:coli+3*bc
            y(i, j) = median(IC(i-br:i+br, j-bc:j+bc).*M, 'all');
        end
    end
    new = y(1+br:rowi+3*br, 1+bc:coli+3*bc);
    y = new;
    imshow(y);
end