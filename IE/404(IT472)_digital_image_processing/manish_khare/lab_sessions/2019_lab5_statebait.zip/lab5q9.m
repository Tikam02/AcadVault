%Robert's Method
I = im2double(imread('lena.png'));

M = [0, -1;
    1, 0];
disp(M);
noise = 0;

J = robert(I, M, noise);
figure();
K = 255*ones(size(J))-J;
for i=1:size(K, 1)
    for j=1:size(K, 2)
        if K(i, j) < 255
            K(i, j) = 0;
        end
    end
end
imshow(K);
figure();
imshow(histeq(J));

function y = robert(I, M, noise)
    [rowi, coli] = size(I);
    [rowm, colm] = size(M);
    br = floor(rowm/2);
    bc = floor(colm/2);
    IC = zeros(rowi+4*br, coli+4*bc);
    y = IC;
    if noise==1
        I = imnoise(I,'salt & pepper');
    end
    imshow(I);
    figure();
    IC(2*br:rowi+2*br-1, 2*bc:coli+2*bc-1) = I;
    for i=1+br:rowi+2*br-1
        for j=1+bc:coli+2*bc-1
            for k=-br:0
                for l=-bc:0
                    y(i, j) = y(i, j) + M(k+br+1, l+bc+1)*IC(i+k, j+l);
                end
            end
        end
    end
    new = y(1+br:rowi+3*br, 1+bc:coli+3*bc);
    y = new;
    imshow(y);
end