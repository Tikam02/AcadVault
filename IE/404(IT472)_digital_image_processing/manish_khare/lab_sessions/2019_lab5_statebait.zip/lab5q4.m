%Order-Statistics (Mean, Median) Filter
I = im2double(imread('lena.png'));
M1 = 3;
M2 = 5;
noise = 0;
type = 1;
M = M2;
J = orderFilter(I, M, noise, type);

function y = orderFilter(I, M, noise, type)
    [rowi, coli] = size(I);
    if noise==1
        I = imnoise(I,'salt & pepper');
    end
    margin = floor(M/2);
    imshow(I);
    figure();
    IC = zeros(rowi+4*margin, coli+4*margin);
    y = IC;
    IC(2*margin+1:rowi+2*margin, 2*margin+1:coli+2*margin) = I;
    for i=1+margin:rowi+3*margin
        for j=1+margin:coli+3*margin
            if type == 0
                for k=-margin:margin
                    for l=-margin:margin
                        y(i, j) = y(i, j) + IC(i+k, j+l)/M^2;
                    end
                end
            else
                y(i, j) = median(IC(i-margin:i+margin, j-margin:j+margin), 'all'); 
            end
            
        end
    end
    new = y(1+margin:rowi+3*margin, 1+margin:coli+3*margin);
    y = new;
    imshow(y);
end