%Gaussian Filter
I = im2double(imread('lena.png'));
N1 = 3;
N2 = 5;
N = N1;
sigma = N/5;
ind = -floor(N/2) : floor(N/2);
[X, Y] = meshgrid(ind, ind);
M = exp(-(X.^2 + Y.^2) / (2*sigma*sigma));
M = M / sum(M(:));
disp(M);
noise = 0;
J = linearFilter(I, M, noise);

function y = linearFilter(I, M, noise)
    [rowi, coli] = size(I);
    [rowm, colm] = size(M);
    br = floor(rowm/2);
    bc = floor(colm/2);
    IC = zeros(rowi+4*br, coli+4*bc);
    y = IC;
    if noise==1
        I = imnoise(I,'salt & pepper');
    end
    imshow(I);
    figure();
    IC(2*br+1:rowi+2*br, 2*bc+1:coli+2*bc) = I;
    for i=1+br:rowi+3*br
        for j=1+bc:coli+3*bc
            for k=-br:br
                for l=-bc:bc
                    y(i, j) = y(i, j) + M(k+br+1, l+bc+1)*IC(i+k, j+l);
                end
            end
        end
    end
    new = y(1+br:rowi+3*br, 1+bc:coli+3*bc);
    y = new;
    imshow(y);
end