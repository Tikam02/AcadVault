%High Boost Filtering
I = im2double(imread('lena.png'));
M1 = ones(3, 3);
M2 = ones(5, 5);
noise = 0;
M = M2;
J = avgFilter(I, M, noise);
figure();
A = 1;
K = A*I - J;
imshow(K);
N = K + I;
imshow(N);

function y = avgFilter(I, M, noise)
    [rowi, coli] = size(I);
    [rowm, colm] = size(M);
    br = floor(rowm/2);
    bc = floor(colm/2);
    M = M/(rowm^2);
    IC = zeros(rowi+4*br, coli+4*bc);
    y = IC;
    if noise==1
        I = imnoise(I,'salt & pepper');
    end
    imshow(I);
    figure();
    IC(2*br+1:rowi+2*br, 2*bc+1:coli+2*bc) = I;
    for i=1+br:rowi+3*br
        for j=1+bc:coli+3*bc
            for k=-br:br
                for l=-bc:bc
                    y(i, j) = y(i, j) + M(k+br+1, l+bc+1)*IC(i+k, j+l);
                end
            end
        end
    end
    new = y(1+2*br:rowi+2*br, 1+2*bc:coli+2*bc);
    y = new;
    imshow(y);
end