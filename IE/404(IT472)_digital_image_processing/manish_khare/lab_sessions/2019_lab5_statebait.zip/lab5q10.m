%Sobel's Method
I = im2double(imread('lena.png'));

M1 = [-1, -2, -1;
    0, 0, 0;
    1, 2, 1];
M2 = [-1, 0, 1;
    -2, 0, 2;
    -1, 0, 1];
M = M2;
noise = 0;

J = sobel(I, M, noise);
figure();
K = 255*ones(size(J))-J;
for i=1:size(K, 1)
    for j=1:size(K, 2)
        if K(i, j) < 255
            K(i, j) = 0;
        end
    end
end
imshow(K);
figure();
imshow(histeq(J));

function y = sobel(I, M, noise)
    [rowi, coli] = size(I);
    [rowm, colm] = size(M);
    br = floor(rowm/2);
    bc = floor(colm/2);
    IC = zeros(rowi+4*br, coli+4*bc);
    y = IC;
    if noise==1
        I = imnoise(I,'salt & pepper');
    end
    imshow(I);
    figure();
    IC(2*br+1:rowi+2*br, 2*bc+1:coli+2*bc) = I;
    for i=1+br:rowi+3*br
        for j=1+bc:coli+3*bc
            for k=-br:br
                for l=-bc:bc
                    y(i, j) = y(i, j) + M(k+br+1, l+bc+1)*IC(i+k, j+l);
                end
            end
        end
    end
    new = y(1+br:rowi+3*br, 1+bc:coli+3*bc);
    y = new;
    imshow(y);
end