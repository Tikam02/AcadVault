% Image Histogram Processing

img = imread('scene.jpg');
img = img(:,:,1);

img_size = size(img);
pdf = imhist(img)/(img_size(1)*img_size(2));
cdf = pdf;
for i=2:256
    cdf(i) = cdf(i)+cdf(i-1);
end

img_eq = img;
for i=1:img_size(1)
    for j=1:img_size(2)
        img_eq(i,j) = 255*cdf(img(i,j)+1);
    end
end

figure
subplot(2,2,1);
imshow(img);
title('Original Image');
subplot(2,2,2);
imshow(img_eq);
title('Equalized Image');
subplot(2,2,3);
imhist(img);
subplot(2,2,4);
imhist(img_eq);