% Image Histogram Matching

M = zeros(256,1,'uint8');
im1 = rgb2gray(imread('lenaTest1.jpg'));
im2 = rgb2gray(imread('im2.jpg'));
hist1 = imhist(im1(:,:,1));
szim1 = size(im1);
hist2 = imhist(im2(:,:,1));
szim2 = size(im2);
cdf1 = cumsum(hist1) / (szim1(1)*szim1(2));
cdf2 = cumsum(hist2) / (szim2(1)*szim2(2));

for idx = 1 : 256
    [~,ind] = min(abs(cdf1(idx) - cdf2));
    M(idx) = ind-1;
end

for i=1:szim1(1)
    for j=1:szim1(2)
        out(i,j,1) = M(im1(i,j,1),1);
    end
end
out = uint8(out);

figure
subplot(2,3,1);
imshow(im1);
subplot(2,3,2);
imshow(im2);
subplot(2,3,3);
imshow(out);
subplot(2,3,4)
imhist(im1);
subplot(2,3,5);
imhist(im2);
subplot(2,3,6);
imhist(out);