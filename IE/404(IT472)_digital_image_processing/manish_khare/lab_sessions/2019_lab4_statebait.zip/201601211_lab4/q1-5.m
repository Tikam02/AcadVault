% Image power Law transformation  
img = imread('lenaTest1.jpg');
img_new = uint8(floor(1*double(img).^(1.085)));

figure
subplot(2,2,1);
imshow(img);
title('Original Image');
subplot(2,2,2);
imshow(img_new);
title('Power-Law Transformed Image');
subplot(2,2,3);
imhist(img);
subplot(2,2,4);
imhist(img_new);