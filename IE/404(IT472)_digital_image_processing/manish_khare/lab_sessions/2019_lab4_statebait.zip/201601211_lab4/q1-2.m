% Image bit Plane Slicing

img = imread('fractal.jpg');

img1 = mod(img, 2)*255; 
img2 = mod(floor(img/2), 2)*255; 
img3 = mod(floor(img/4), 2)*255; 
img4 = mod(floor(img/8), 2)*255; 
img5 = mod(floor(img/16), 2)*255; 
img6 = mod(floor(img/32), 2)*255; 
img7 = mod(floor(img/64), 2)*255; 
img8 = mod(floor(img/128), 2)*255;

figure
subplot(3,3,1);
imshow(img);
title('Original Image');
subplot(3,3,2);
imshow(img1);
title('Bit plane 0');
subplot(3,3,3);
imshow(img2);
title('Bit plane 1');
subplot(3,3,4);
imshow(img3);
title('Bit plane 2');
subplot(3,3,5);
imshow(img4);
title('Bit plane 3');
subplot(3,3,6);
imshow(img5);
title('Bit plane 4');
subplot(3,3,7);
imshow(img6);
title('Bit plane 5');
subplot(3,3,8);
imshow(img7);
title('Bit plane 6');
subplot(3,3,9);
imshow(img8);
title('Bit plane 7');