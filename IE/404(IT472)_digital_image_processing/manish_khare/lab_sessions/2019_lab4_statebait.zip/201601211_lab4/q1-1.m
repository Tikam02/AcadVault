% Negative of an image

img = imread('lena.jpg');
image_negative = 255 - img;
figure
subplot(2,2,1)
imshow(img);
title('Original Image');
subplot(2,2,2);
imshow(image_negative);
title('Negative of Image');
subplot(2,2,3);
imhist(img);
subplot(2,2,4);
imhist(image_negative);