% Image log transformation  

img = imread('lenaTest1.jpg');
img_new = uint8(floor(100*log(1+double(img))/log(10)));

figure
subplot(2,2,1);
imshow(img);
title('Original Image');
subplot(2,2,2);
imshow(img_new);
title('Log Transformed Image');
subplot(2,2,3);
imhist(img);
subplot(2,2,4);
imhist(img_new);