% Image contrast Stretching

img = imread('lenaTest1.jpg');
img = img(:,:,1);
a = min(img(:));
b = max(img(:));
img_new = (img-a).*(255/(b-a));
figure;
subplot(2,2,1);
imshow(img);
title('Original Image');
subplot(2,2,2);
imshow(img_new);
title('Contrast Stretched Image');
subplot(2,2,3);
imhist(img);
subplot(2,2,4);
imhist(img_new);