% 1
I=imread('lenaTest1.jpg');

% 2
imshow(I);

% 3
imwrite(I,'lena.jpg');

% 4
imfinfo('lena.jpg');

% 5
I2 = im2uint8(I);
imshow(I2);

% 6
I3=rgb2gray(I2);
imshow(I3);

% 7
I4=flip(I);
imshow(I4);

% 8
G=imread('len.jpg');
I=imresize(I, [1000 1000]);
G=im2uint8(G);
G=imresize(G, [1000 1000]);
H=imadd(G,I);
imshow(H);
H=imsubtract(G,I);
imshow(H);
H=immultiply(G,I);
imshow(H);
H=imdivide(G,I);
imshow(H);
H=imabsdiff(G,I);
imshow(H);
H=imcomplement(I);
imshow(H);
H=imlincomb(1.5,G,0.5,I);
imshow(H);
G=imresize(G, [10 10]);
I=imresize(I, [10 10]);

% 9
G>=I;
G==I;

% 10
an=bitand(G,I);
an=bitor(G,I);
an=bitcmp(I);

% 11
sum=0;
for i=1:10
    for j=1:10
        sum=sum+I(i,j);
    end
end
sum=sum/10;
disp(sum);

%12
J=imcrop(K);
imshow(J);