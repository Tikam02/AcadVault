function[op_img] = zero_order_hold(ip_img)
[m,n] = size(ip_img);
op_img = zeros([m*2-1,n*2-1]);
for i = 1:2:m*2-1
    op_img(i,1:2:n*2-1)=ip_img(ceil(i/2),:);
end
for i = 1:2:m*2-1
    for j = 2:2:n*2-1
        op_img(i,j)=floor((op_img(i,j-1)+op_img(i,j+1))/2);
    end
end
for i = 2:2:m*2-1
    for j=1:1:n*2-1
        op_img(i,j)=floor((op_img(i-1,j)+op_img(i+1,j))/2);
    end
end
figure
subplot(1,2,1)
heatmap(ip_img)
subplot(1,2,2)
heatmap(op_img)
end
