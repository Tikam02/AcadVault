% ii - Zooming by Zero Order Hold
input = randi([0,255],10);
k=1;
for i=1:k
    op = zero_order_hold(input);
    input = op;
end