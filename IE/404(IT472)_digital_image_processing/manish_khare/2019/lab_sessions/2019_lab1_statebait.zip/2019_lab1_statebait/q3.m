% iii - Zooming by K-times zooming
input = randi([0,255],10);
for k=2:3
    op = kzoom(input,k);
end