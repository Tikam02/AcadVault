% i - Zooming by Pixel Replication
ip_img = randi([0,255],10);
k = 7;
op_img = zeros(10*k);
for i = 1:1:10*k
    for j = 1:1:10*k
        op_img(i,j) = ip_img(ceil(i/k),ceil(j/k));
    end
end
figure
subplot(1,2,1)
heatmap(ip_img)
subplot(1,2,2)
heatmap(op_img)
