% Name: Mohamed Shadab
% ID: 201601211

img = imread('lena.jpg');
butterhighfunc(img,10,1);
