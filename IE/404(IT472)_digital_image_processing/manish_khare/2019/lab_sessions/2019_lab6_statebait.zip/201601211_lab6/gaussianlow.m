% Name: Mohamed Shadab
% ID: 201601211

img = imread('lena.jpg');
gausslowfunc(img,50);
