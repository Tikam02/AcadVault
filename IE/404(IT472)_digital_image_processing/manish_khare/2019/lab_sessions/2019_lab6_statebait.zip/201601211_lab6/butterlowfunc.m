% Name: Mohamed Shadab
% ID: 201601211

function[] = butterlowfunc(im,d,n)
h=size(im,1);
w=size(im,2);
fftim = fftshift(fft2(double(im)));
[x y]=meshgrid(-floor(w/2):floor(w/2)-1,-floor(h/2):floor(h/2)-1);
B = sqrt(2) - 1;
D = sqrt(x.^2 + y.^2);
hhp = 1 ./ (1 + B * ((D ./ d).^(2 * n)));
out_spec_centre = fftim .* hhp;
out_spec = ifftshift(out_spec_centre);
out = real(ifft2(out_spec));
out = (out - min(out(:))) / (max(out(:)) - min(out(:)));
out = uint8(255*out);
imshow(im),figure,imshow(out);
end