% Name: Mohamed Shadab
% ID: 201601211

img = imread('lena.jpg');
idealhighfunc(img,50);
