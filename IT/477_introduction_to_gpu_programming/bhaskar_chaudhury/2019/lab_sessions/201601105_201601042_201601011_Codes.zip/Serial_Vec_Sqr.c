#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>

#define ull unsigned long long

void vectorAddition(double* a, double* c,ull i)
{
    c[i] = a[i]* a[i];
}

int main()
{
        ull maxSize = pow(2,29), minSize,size, total;
        minSize = pow(2,10);
        size = minSize;
        total = maxSize;
        for(;size<=maxSize;size*=2){
                ull RUNS = total/size;
                double *A,*C;
                A = (double*)malloc(size*sizeof(double));
                C = (double*)malloc(size*sizeof(double));
                ull i;
                for(i = 0;i<size;i++){
                    A[i] = i;
                }
                ull j;
                clock_t start = clock();
                for(j = 0;j<RUNS;j++){
                    for(i = 0;i<size;i++){
                        vectorAddition(A,C,i);
                    }
                }
                clock_t end = clock();
                double tot_time = (double)(end-start);
                double throughput = (sizeof(double)*total)/tot_time;
                printf("Size: %lld Time: %f Throughput: %f\n",size,tot_time,throughput);
        }
        return 0;
}
