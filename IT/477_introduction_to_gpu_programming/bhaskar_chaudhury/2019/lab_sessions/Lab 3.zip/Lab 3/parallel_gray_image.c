#include<stdio.h>
#include<stdlib.h>
#include<cuda.h>

#define ull unsigned long long

double* rgb2gray(double* img, int x, int y){
    double* gray;
    gray = malloc(sizeof(double)*x*y);
    int idx;
    for(idx = 0;idx<x*y;idx++){
        double r = img[3*idx];
        double g = img[3*idx + 1];
        double b = img[3*idx + 2];
        gray[idx] = (0.21*r + 0.71*g + 0.07*b);
    }
    return gray;
}

int main()
{

    ull maxSize = pow(2,14), minSize,size, total;
    minSize = pow(2,5);
    size = minSize;
    total = maxSize;
    for(;size<=maxSize;size*=2)
    {
          ull RUNS = total/size;
          ull i;
          ull j=0;

          double* image = malloc(3*sizeof(double)*size*size);
          double* devImage = cudaMalloc(3*sizeof(double)*size*size);
          double* devGray = cudaMalloc(sizeof(double)*size*size);
          
          for(i=0; i<3*size*size; i++)
          {
               image[i] = rand()%255;
          }
          
          cudaMemcpy(devImage,image,3*sizeof(double)*size*size,cudaMemcpyHostToDevice);
          
          cudaEvent_t start,stop;
          cudaEventCreate(&start);
          cudaEventCreate(&stop);

          cudaEventRecord(start);

          for(; j<RUNS*RUNS; j++)
               rgb2gray(image, size, size);

          cudaEventRecord(stop);
          cudaEventSynchronize(stop);

          float tot_time=0;
          cudaEventElapsedTime(&tot_time,start,stop);
          double throughput = (sizeof(double)*total)/tot_time;
          printf("Size: %lld Time: %f Throughput: %f\n",size,tot_time,throughput);
    }

    
    return 0;
}