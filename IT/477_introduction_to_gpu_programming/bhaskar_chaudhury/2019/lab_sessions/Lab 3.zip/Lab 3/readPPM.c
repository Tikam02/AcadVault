#include<stdio.h>
#include<stdlib.h>

typedef struct {
     unsigned char red,green,blue;
} PPMPixel;

typedef struct {
     int x, y;
     PPMPixel *data;
} PPMImage;

#define CREATOR "RPFELGUEIRAS"
#define RGB_COMPONENT_COLOR 255

static PPMImage *readPPM(const char *filename)
{
         char buff[16];
         PPMImage *img;
         FILE *fp;
         int c, rgb_comp_color;
         //open PPM file for reading
         fp = fopen(filename, "rb");
         if (!fp) {
              fprintf(stderr, "Unable to open file '%s'\n", filename);
              exit(1);
         }

         //read image format
         if (!fgets(buff, sizeof(buff), fp)) {
              perror(filename);
              exit(1);
         }

    //check the image format
    if (buff[0] != 'P' || buff[1] != '6') {
         fprintf(stderr, "Invalid image format (must be 'P6')\n");
         exit(1);
    }

    //alloc memory form image
    img = (PPMImage *)malloc(sizeof(PPMImage));
    if (!img) {
         fprintf(stderr, "Unable to allocate memory\n");
         exit(1);
    }

    //check for comments
    c = getc(fp);
    while (c == '#') {
    while (getc(fp) != '\n') ;
         c = getc(fp);
    }

    ungetc(c, fp);
    //read image size information
    if (fscanf(fp, "%d %d", &img->x, &img->y) != 2) {
         fprintf(stderr, "Invalid image size (error loading '%s')\n", filename);
         exit(1);
    }

    //read rgb component
    if (fscanf(fp, "%d", &rgb_comp_color) != 1) {
         fprintf(stderr, "Invalid rgb component (error loading '%s')\n", filename);
         exit(1);
    }

    //check rgb component depth
    if (rgb_comp_color!= RGB_COMPONENT_COLOR) {
         fprintf(stderr, "'%s' does not have 8-bits components\n", filename);
         exit(1);
    }

   
    while (fgetc(fp) != '\n') ;
    //memory allocation for pixel data
    img->data = (PPMPixel*)malloc(img->x * img->y * sizeof(PPMPixel));

    if (!img) {
         fprintf(stderr, "Unable to allocate memory\n");
         exit(1);
    }

    //read pixel data from file
    if (fread(img->data, 3 * img->x, img->y, fp) != img->y) {
         fprintf(stderr, "Error loading image '%s'\n", filename);
         exit(1);
    }

    fclose(fp);
    return img;
}
void writePPM(const char *filename, PPMImage *img)
{
    FILE *fp;
    //open file for output
    fp = fopen(filename, "wb");
    if (!fp) {
         fprintf(stderr, "Unable to open file '%s'\n", filename);
         exit(1);
    }

    //write the header file
    //image format
    fprintf(fp, "P6\n");

    //comments
    fprintf(fp, "# Created by %s\n",CREATOR);

    //image size
    fprintf(fp, "%d %d\n",img->x,img->y);

    // rgb component depth
    fprintf(fp, "%d\n",RGB_COMPONENT_COLOR);

    // pixel data
    fwrite(img->data, 3 * img->x, img->y, fp);
    fclose(fp);
}

double* rgb2gray(double* img, int x, int y){
    double* gray;
    gray = malloc(sizeof(double)*x*y);
    int idx;
    for(idx = 0;idx<x*y;idx++){
        double r = img[3*idx];
        double g = img[3*idx + 1];
        double b = img[3*idx + 2];
        gray[idx] = (0.21*r + 0.71*g + 0.07*b);
    }
    return gray;
}

void writeImage(double* img, int width, int height){
    FILE* pgmimg; 
    pgmimg = fopen("gray.pgm", "wb"); 
  
    // Writing Magic Number to the File 
    fprintf(pgmimg, "P2\n");  
    printf("%d\n",pgmimg);
    // Writing Width and Height 
    fprintf(pgmimg, "%d %d\n", width, height);  
  
    // Writing the maximum gray value 
    fprintf(pgmimg, "255\n");  
    int count = 0; 
    int i;
    for (i = 0; i < width*height; i++) { 
        
        double temp = img[i]; 
        fprintf(pgmimg, "%d ", (int)temp); 
        if ((i+1)%width == 0)
            fprintf(pgmimg, "\n"); 
    } 
    fclose(pgmimg); 
}

int main()
{
    PPMImage* image = readPPM("dilbert.ppm");
    int i;
    double *img;
    img = malloc(3*sizeof(double)*image->x*image->y);
    for(i=0;i<image->x*image->y;i++){
        img[3*i] = image->data[i].red;
        img[3*i+1] = image->data[i].green;
        img[3*i+2] = image->data[i].blue;
    }
    double* grayImg = rgb2gray(img,image->y,image->x);
    // for(i=0;i<image->x*image->y;i++){
    //     printf("%f ",grayImg[i]);
    //     if((i+1)%image->y == 0)
    //         printf("\n");
    // }
    writeImage(grayImg,image->y,image->x);
    return 0;
}